using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UIForia.Test")]