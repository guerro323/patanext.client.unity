namespace SVGX {

    public enum DrawCallType {

        StandardStroke,
        StandardFill,
        ShadowStroke,
        ShadowFill

    }

}