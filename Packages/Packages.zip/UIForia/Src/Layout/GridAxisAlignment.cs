namespace UIForia.Layout {
  
    public enum GridAxisAlignment {
        Unset = 0,
        Start = 1,
        Center = 2,
        End = 3,
        Grow = 4,
        Fit = 5,
        Shrink = 6
    }
    
}