namespace UIForia.Layout {

    public enum LayoutWrap {

        Unset = 0,
        None = 0,
        WrapHorizontal = 1,

    }

}