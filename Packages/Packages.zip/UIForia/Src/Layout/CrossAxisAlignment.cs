namespace UIForia.Layout {

    public enum CrossAxisAlignment {

        Unset = 0,
        Start = 1,
        Center = 2,
        End = 3,
        Stretch = 4

    }

}