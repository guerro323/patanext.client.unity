namespace UIForia.Layout {

    public struct ItemAlignment {

        public const float Start = 0f;
        public const float Center = 0.5f;
        public const float End = 1f;

    }

}