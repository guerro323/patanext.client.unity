namespace UIForia.Layout {

    public enum GridLayoutDensity {
        Unset = 0,
        Sparse = 1 << 0,
        Dense = 1 << 1

    }

}