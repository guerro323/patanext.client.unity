namespace UIForia.Layout {
    public enum ScrollBehavior {
        Default = 0,
        Fixed
    }
}