namespace UIForia.Layout {

    public enum LayoutFlowType {
        Unset,
        InFlow,
        OutOfFlow
    }

}