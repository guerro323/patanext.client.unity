namespace UIForia.Layout {

    public enum LayoutDirection {

        Unset = 0,
        Horizontal = 1,
        Vertical = 2
    }

}