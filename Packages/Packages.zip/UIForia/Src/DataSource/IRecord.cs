namespace UIForia.DataSource {

    public interface IRecord {

        long Id { get; set; }

    }

}