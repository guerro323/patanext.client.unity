namespace UIForia.Text {

    public enum TextTransform {

        None = 0,
        UpperCase = 1,
        LowerCase = 2,
        SmallCaps = 3,
        TitleCase = 4,
        SuperScript = 5,
        SubScript = 6

    }

}