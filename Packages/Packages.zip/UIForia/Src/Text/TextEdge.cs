namespace UIForia.Text {

    public enum TextEdge {

        Right,
        Left

    }

}