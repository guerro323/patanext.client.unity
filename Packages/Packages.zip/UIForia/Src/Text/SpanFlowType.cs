namespace UIForia.Text {

    public enum SpanFlowType {

        Inline = 0,
        Left = 1,
        Right = 2,
        Nonblocking = 3

    }

}