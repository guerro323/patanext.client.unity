﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UIForia.Test")]
[assembly: InternalsVisibleTo("UIForia.Editor")]
[assembly: InternalsVisibleTo("UIForia.Generated")]
