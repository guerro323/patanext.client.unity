namespace UIForia.Animation {

    public enum AnimationTaskType {

        Style,
        Generic

    }

}