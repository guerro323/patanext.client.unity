namespace UIForia.Animation {
    public enum AnimationType {
        KeyFrame, SpriteSheet
    }
}
