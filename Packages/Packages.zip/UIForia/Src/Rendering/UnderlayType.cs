namespace UIForia.Rendering {

    public enum UnderlayType {

        Unset = 0,
        None = 1 << 0,
        Normal = 1 << 1,
        Inset = 1 << 2
    }

}