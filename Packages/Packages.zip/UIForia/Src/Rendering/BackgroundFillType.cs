namespace UIForia.Rendering {

    public enum BackgroundFillType {

        Unset = 0,
        None = 1,
        Normal = 2,
        Gradient = 3,
        Grid = 4,
        Checker = 5,
        Stripes = 6

    }

}