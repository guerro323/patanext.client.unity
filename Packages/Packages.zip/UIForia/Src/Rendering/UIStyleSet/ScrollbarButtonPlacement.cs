namespace UIForia.Rendering {

    public enum ScrollbarButtonPlacement {

        Unset = 0,
        Hidden = 1, 
        TogetherBefore = 2,
        TogetherAfter = 3,
        Apart = 4

    }

}