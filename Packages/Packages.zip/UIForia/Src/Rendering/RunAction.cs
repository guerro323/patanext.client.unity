namespace UIForia.Rendering  {
    public enum RunAction {
        Run,
        Pause,
        Resume,
        Stop,
    }
}
