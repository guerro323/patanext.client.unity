namespace UIForia.Rendering {

    public enum ClipBounds {

        Unset = 0,
        ContentBox,
        BorderBox
        
    }

}