namespace UIForia.Rendering {

    public enum BorderStyle {

        Solid,
        Dashed,
        Dotted,
        Unset

    }

}