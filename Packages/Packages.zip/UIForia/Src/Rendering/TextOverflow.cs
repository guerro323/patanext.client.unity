namespace UIForia.Rendering {

    public enum TextOverflow {

        Wrap,
        Truncate,
        Overflow,
        Unset

    }

}