using System;

namespace UIForia.Attributes {
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class AcceptFocus : Attribute { }
}