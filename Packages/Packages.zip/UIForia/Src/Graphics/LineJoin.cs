namespace Vertigo {

    public enum LineJoin {

        None,
        Miter,
        MiterClip,
        Bevel,
        Round

    }

}