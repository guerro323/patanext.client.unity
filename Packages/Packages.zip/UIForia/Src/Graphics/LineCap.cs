namespace Vertigo {

    public enum LineCap {

        Butt = 0,
        Square = 1,
        Round = 2,
        TriangleOut = 3,
        TriangleIn = 4

    }

}