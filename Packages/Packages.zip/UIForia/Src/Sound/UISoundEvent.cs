using UIForia.Elements;

namespace UIForia.Sound {
    public struct UISoundEvent {
        public UIElement Origin;
        public UISoundData SoundData;
    }
}
