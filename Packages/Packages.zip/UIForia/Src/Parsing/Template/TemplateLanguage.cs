namespace UIForia.Parsing {

    public enum TemplateLanguage {

        XML

    }

}