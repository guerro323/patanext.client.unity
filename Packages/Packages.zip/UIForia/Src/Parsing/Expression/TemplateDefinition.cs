namespace UIForia.Parsing {

    public struct TemplateDefinition {

        public string contents;
        public TemplateLanguage language;
        public string filePath;
        public string templateId;

    }

}