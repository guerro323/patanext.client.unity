namespace UIForia.Parsing.Style.AstNodes {
    public abstract class CommandNode : StyleASTNode {

    }
}
