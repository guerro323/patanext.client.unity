namespace UIForia.Systems {

    public abstract class TemplateContext { }

}