using System;

namespace UIForia.Compilers {

    // public struct ScopedContextVariable {
    //
    //     public int id;
    //     public Type type;
    //     public string name;
    //         
    // }

}