namespace UIForia.Compilers {

    public enum CompiledBindingType {

        OnCreate, OnEnable, OnUpdate, OnLateUpdate

    }

}