namespace UIForia {

    public sealed class Terminal { } // represents a void type in generics

}