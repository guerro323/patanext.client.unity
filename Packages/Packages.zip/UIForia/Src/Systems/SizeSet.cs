using UIForia.Layout;

namespace UIForia.Systems {

    public struct SizeSet {

        public Size size;
        public Size allocatedSize;
        public Size contentSize;

    }

}