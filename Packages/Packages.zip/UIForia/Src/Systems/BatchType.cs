namespace UIForia.Rendering {

    public enum BatchType {

        Unset,
        UIForia,
        Path,
        Custom,

        Mesh,

        Clip

    }

}