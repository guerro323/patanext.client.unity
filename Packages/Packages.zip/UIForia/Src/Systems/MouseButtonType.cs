namespace Packages.UIForia.Src.Systems {
    public enum MouseButtonType {
        Left, Middle, Right
    }
}
