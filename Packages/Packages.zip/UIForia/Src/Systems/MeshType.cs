﻿namespace UIForia.Rendering {

    public enum MeshType {

        Simple,
        FillRadial90,
        FillRadial180,
        FillRadial360,
        FillHorizontal,
        FillVertical,

    }

}