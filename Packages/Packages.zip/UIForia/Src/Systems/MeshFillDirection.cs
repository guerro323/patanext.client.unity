﻿namespace UIForia.Rendering {

    public enum MeshFillDirection {

        Clockwise,
        CounterClockwise

    }

}