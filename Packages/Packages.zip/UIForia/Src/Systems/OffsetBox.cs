namespace UIForia.Systems {

    public struct OffsetBox {

        public float left;
        public float right;
        public float top;
        public float bottom;

    }

}