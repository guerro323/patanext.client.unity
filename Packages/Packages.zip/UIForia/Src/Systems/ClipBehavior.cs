namespace UIForia.Layout {

    public enum ClipBehavior {

        Never,
        Normal,
        View,
        Screen,
        Skip

    }

}