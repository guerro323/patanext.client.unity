namespace Systems.SelectorSystem {

    public enum NavigationOperator {

        Gather,
        Parent,
        Ancestor,
        Sibling

    }

}