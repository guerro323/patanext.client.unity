namespace Systems.SelectorSystem {

    public class SelectorFilter {

        public int size;

    }

}