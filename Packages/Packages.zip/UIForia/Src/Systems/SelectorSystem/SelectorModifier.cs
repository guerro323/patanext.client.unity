namespace Systems.SelectorSystem {

    public class SelectorModifier { }

}