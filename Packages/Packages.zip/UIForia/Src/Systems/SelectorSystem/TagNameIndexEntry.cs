using UIForia.Elements;

namespace Systems.SelectorSystem {

    public struct TagNameIndexEntry {

        public int depth;
        public int templateId;
        public UIElement element;

    }

}