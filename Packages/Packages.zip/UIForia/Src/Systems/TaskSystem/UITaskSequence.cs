namespace UIForia.Systems {

    public class UITaskSequence : UITaskGroup {

        // run all tasks seqentially
        // stop when all are done or any cancel

    }

}