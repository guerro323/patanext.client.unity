namespace UIForia.Layout {

    public enum LayoutFit {

        Unset = 0,
        Default,
        None,
        Grow,
        Shrink,
        Fill,
        FillParent

    }

}