namespace UIForia.Systems {

    public struct AxisAlignedBounds {

        public float xMin;
        public float yMin;
        public float xMax;
        public float yMax;

    }

}