namespace UIForia.Elements {

    public interface IInputFormatter {

        string Format(string input);

    }

}