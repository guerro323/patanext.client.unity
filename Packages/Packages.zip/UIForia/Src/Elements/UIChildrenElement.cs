namespace UIForia.Elements {

    public class UIChildrenElement : UISlotOverride {
        
        public override string GetDisplayName() {
            return "slot:children";
        }

    }

}