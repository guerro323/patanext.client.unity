namespace UIForia.Elements {
    public sealed class SubmitEvent : UIEvent {
        public SubmitEvent() : base("submit") {}
    }
}
