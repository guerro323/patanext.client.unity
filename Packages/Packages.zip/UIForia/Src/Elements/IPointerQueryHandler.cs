using UnityEngine;

namespace UIForia.Elements {

    public interface IPointerQueryHandler {

        bool ContainsPoint(Vector2 point);

    }

}