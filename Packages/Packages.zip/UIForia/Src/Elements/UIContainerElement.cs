namespace UIForia.Elements {

    public abstract class UIContainerElement : UIElement {}

}