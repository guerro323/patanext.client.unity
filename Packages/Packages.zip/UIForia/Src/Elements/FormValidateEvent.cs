namespace UIForia.Elements {

    public class FormValidateEvent {

        public void Fail(string key, string message) { }

    }

}