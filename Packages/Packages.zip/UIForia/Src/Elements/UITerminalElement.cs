namespace UIForia.Elements {

    public class UITerminalElement : UIElement { }

}